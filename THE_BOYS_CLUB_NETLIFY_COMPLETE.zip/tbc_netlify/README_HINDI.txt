THE BOYS CLUB — NETLIFY PROJECT
================================

IS PROJECT MEIN:
- Mobile-friendly THE BOYS CLUB website
- 4 hero photos ka automatic slider (3 seconds)
- Product categories, wishlist, WhatsApp order form
- Ticker par 8 taps ke baad admin login
- Secure server-side password check (password HTML/JS mein nahi hai)
- Admin: products add/edit/delete
- Admin: shop slider photos upload/delete
- Shared persistent data via Netlify Blobs: ek admin update karega to sab visitors ko updated products/photos dikhenge
- Image upload JPG/PNG/WEBP, max 5 MB

IMPORTANT LIMITATIONS:
- Orders abhi WhatsApp par khulte hain; Netlify database mein order history save nahi hoti.
- Customers ko latest updates dekhne ke liye page refresh karna pad sakta hai.
- Netlify free plan unlimited nahi hai. Usage limits apply.
- Netlify Drop par sirf public folder drag karna backend deploy nahi karega. GitHub se poora project import karna zaroori hai.

PHONE SE DEPLOY KARNE KA TARIKA:
1. ZIP extract karo. Folder ke andar netlify.toml, package.json, public aur netlify folder dikhne chahiye.
2. GitHub.com par login/create account karo.
3. New repository banao: the-boys-club
4. Extracted project ke andar ki saari files/folders repository ke ROOT mein upload karo. Aisa na ho ki repository ke andar ek extra nested project folder ho.
   Root mein netlify.toml, package.json, public/, netlify/ hone chahiye.
5. Netlify.com par login karo.
6. Add new project / Import an existing project → GitHub choose karo.
7. the-boys-club repository select karo.
8. Build settings:
   Build command: npm install
   Publish directory: public
   Functions directory: netlify/functions (netlify.toml se auto-detect bhi hoga)
9. Deploy project dabao.

ADMIN PASSWORD SET KARNA (DEPLOY SE PEHLE YA BAAD):
1. Netlify Dashboard → apna site → Site configuration (ya Project configuration)
2. Environment variables kholo.
3. Add variable:
   Key: ADMIN_PASSWORD
   Value: apna alag, lamba password
   Scope/Secret option available ho to secret rakho.
4. Dusra variable:
   Key: SESSION_SECRET
   Value: kam se kam 40 random characters ka alag secret
5. Save karo.
6. Deploys tab → Trigger deploy → Deploy site.

Password aur SESSION_SECRET kisi ko mat bhejna, chat mein bhi nahi.
Admin login:
- Website kholo.
- Upar black ticker strip par 15 seconds ke andar 8 baar tap karo.
- Admin password enter karo.

ADMIN UPDATES:
Admin Dashboard → Add/Edit Product → photo select → Save Product.
Shop photos section → photos select → Upload.
Delete/Edit buttons se products manage karo.
Changes shared Netlify Blobs storage mein persist hote hain; visitors ko same data milta hai.

CUSTOM DOMAIN:
Netlify Site → Domain management → Add a domain. Domain alag se kharidna pad sakta hai.

SECURITY:
- Admin password backend function mein check hota hai; frontend source mein nahi.
- Session HttpOnly + Secure + SameSite=Strict cookie use karti hai.
- SESSION_SECRET ko kabhi public mat karo.
- Production launch se pehle login rate limiting aur order persistence add karwana behtar hoga.
