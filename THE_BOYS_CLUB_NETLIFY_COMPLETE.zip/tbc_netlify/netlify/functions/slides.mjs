import { json, isAdmin, unauthorized, readJSON, writeJSON } from './_lib.mjs';
export default async (req) => {
 try{
  let items=await readJSON('slides',[]);
  if(req.method==='GET')return json(items);
  if(!await isAdmin(req))return unauthorized();
  if(req.method==='POST'){
   const {image}=await req.json(); if(!image || !String(image).startsWith('/.netlify/functions/media?key='))return json({error:'Upload a valid shop photo first.'},400);
   const item={id:crypto.randomUUID(),image}; items.push(item); await writeJSON('slides',items); return json({ok:true});
  }
  if(req.method==='DELETE'){
   const id=new URL(req.url).searchParams.get('id'); items=items.filter(x=>x.id!==id); await writeJSON('slides',items); return json({ok:true});
  }
  return json({error:'Method not allowed'},405);
 }catch(e){return json({error:e.message||'Server error'},500)}
};
