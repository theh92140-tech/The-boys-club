import { json, isAdmin } from './_lib.mjs';
export default async (req) => json({admin:await isAdmin(req)});
