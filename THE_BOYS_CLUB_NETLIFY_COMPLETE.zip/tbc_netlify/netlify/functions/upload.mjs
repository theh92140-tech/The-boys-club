import { json, isAdmin, unauthorized, mediaStore, validImageType } from './_lib.mjs';
export default async (req) => {
 if(req.method!=='POST')return json({error:'Method not allowed'},405);
 if(!await isAdmin(req))return unauthorized();
 try{
  const form=await req.formData(); const file=form.get('file');
  if(!file || typeof file.arrayBuffer!=='function')return json({error:'Choose an image.'},400);
  if(!validImageType(file.type))return json({error:'Only JPG, PNG and WEBP images are allowed.'},400);
  if(file.size>5*1024*1024)return json({error:'Image must be under 5 MB.'},400);
  const key=crypto.randomUUID(); const bytes=await file.arrayBuffer();
  await mediaStore().set(key,bytes,{metadata:{contentType:file.type}});
  return json({url:`/.netlify/functions/media?key=${key}`});
 }catch(e){return json({error:e.message||'Upload failed'},500)}
};
