import { json, clearCookie } from './_lib.mjs';
export default async (req) => req.method==='POST' ? json({ok:true},200,{'set-cookie':clearCookie}) : json({error:'Method not allowed'},405);
