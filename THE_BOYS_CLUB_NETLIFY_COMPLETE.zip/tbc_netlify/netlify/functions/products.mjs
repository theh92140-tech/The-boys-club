import { json, isAdmin, unauthorized, readJSON, writeJSON } from './_lib.mjs';
export default async (req) => {
 try {
  let items=await readJSON('products',[]);
  if(req.method==='GET') return json(items);
  if(!await isAdmin(req)) return unauthorized();
  if(req.method==='POST'||req.method==='PUT'){
   const p=await req.json();
   if(!p.id||!p.name||!p.price||!p.image) return json({error:'Name, price, and photo are required.'},400);
   const clean={id:String(p.id),name:String(p.name).slice(0,100),category:String(p.category||'Jeans'),desc:String(p.desc||'').slice(0,500),sizes:String(p.sizes||'').slice(0,100),old:String(p.old||''),price:String(p.price),image:String(p.image)};
   items=items.filter(x=>x.id!==clean.id); items.unshift(clean); await writeJSON('products',items); return json({ok:true});
  }
  if(req.method==='DELETE'){
   const id=new URL(req.url).searchParams.get('id'); if(!id)return json({error:'Missing product id'},400);
   items=items.filter(x=>x.id!==id); await writeJSON('products',items); return json({ok:true});
  }
  return json({error:'Method not allowed'},405);
 }catch(e){return json({error:e.message||'Server error'},500)}
};
