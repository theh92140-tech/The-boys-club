import { json, makeSession, cookieHeader } from './_lib.mjs';
export default async (req) => {
  if(req.method!=='POST') return json({error:'Method not allowed'},405);
  try {
    const {password=''}=await req.json();
    const expected=process.env.ADMIN_PASSWORD;
    if(!expected) return json({error:'ADMIN_PASSWORD is not configured in Netlify.'},500);
    if(typeof password!=='string' || password.length>200 || password!==expected) return json({error:'Incorrect password.'},401);
    const token=await makeSession();
    return json({ok:true},200,{'set-cookie':cookieHeader(token)});
  } catch(e){return json({error:e.message||'Login failed'},500)}
};
