import { mediaStore, json } from './_lib.mjs';
export default async (req) => {
 const key=new URL(req.url).searchParams.get('key'); if(!key || !/^[a-f0-9-]{36}$/i.test(key))return json({error:'Not found'},404);
 const obj=await mediaStore().getWithMetadata(key,{type:'arrayBuffer'}); if(!obj)return json({error:'Not found'},404);
 const type=obj.metadata?.contentType||'application/octet-stream';
 return new Response(obj.data,{headers:{'content-type':type,'cache-control':'public, max-age=31536000, immutable','x-content-type-options':'nosniff'}});
};
