import { getStore } from '@netlify/blobs';

export const json = (data, status=200, extra={}) => new Response(JSON.stringify(data), {status, headers:{'content-type':'application/json; charset=utf-8', 'cache-control':'no-store', ...extra}});
export const store = () => getStore({name:'the-boys-club-data', consistency:'strong'});
export const mediaStore = () => getStore({name:'the-boys-club-media', consistency:'strong'});
export const readJSON = async (key, fallback) => { const s=store(); return (await s.get(key,{type:'json'})) ?? fallback; };
export const writeJSON = async (key, value) => store().setJSON(key,value);

const enc = new TextEncoder();
const b64 = (bytes) => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
async function sign(value){
  const secret=process.env.SESSION_SECRET;
  if(!secret || secret.length<32) throw new Error('SESSION_SECRET is missing or too short.');
  const key=await crypto.subtle.importKey('raw',enc.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);
  return b64(await crypto.subtle.sign('HMAC',key,enc.encode(value)));
}
export async function makeSession(){
  const payload=b64(crypto.getRandomValues(new Uint8Array(24)))+'.'+(Date.now()+8*60*60*1000);
  return payload+'.'+await sign(payload);
}
export async function isAdmin(req){
  const cookie=(req.headers.get('cookie')||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('tbc_admin='));
  if(!cookie)return false;
  const token=decodeURIComponent(cookie.slice('tbc_admin='.length));
  const parts=token.split('.'); if(parts.length!==3)return false;
  const payload=parts[0]+'.'+parts[1];
  if(Number(parts[1])<Date.now())return false;
  try{return (await sign(payload))===parts[2]}catch{return false}
}
export const cookieHeader = token => `tbc_admin=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=28800`;
export const clearCookie = 'tbc_admin=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0';
export const unauthorized = () => json({error:'Please login as admin.'},401);
export function validImageType(type){return ['image/jpeg','image/png','image/webp'].includes(type)}
